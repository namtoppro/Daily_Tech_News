# Daily Tech News ?�동 ?�집 �?배포 ?�크립트
# ?�업 ?��?줄러?�서 매일 ?�동 ?�행

# UTF-8 ?�코???�정 (?��? �??�모지 지??
$OutputEncoding = [System.Text.Encoding]::UTF8
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$env:PYTHONIOENCODING = "utf-8"

# 로그 ?�일 ?�정
$LogFile = "d:\anti\git-news\logs\$(Get-Date -Format 'yyyy-MM-dd').log"
$LogDir = Split-Path -Parent $LogFile
if (-not (Test-Path $LogDir)) {
    New-Item -ItemType Directory -Path $LogDir -Force | Out-Null
}

function Write-Log {
    param($Message)
    $Timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $LogMessage = "$Timestamp - $Message"
    # UTF-8�?로그 ?�??
    Add-Content -Path $LogFile -Value $LogMessage -Encoding UTF8
    Write-Host $LogMessage
}

Write-Log "=========================================="
Write-Log "Daily Tech News ?�동 ?�집 ?�작"
Write-Log "=========================================="

# ?�업 ?�렉?�리�??�동
Set-Location "d:\anti\git-news"
Write-Log "?�업 ?�렉?�리: $(Get-Location)"

# 1. ?�스 ?�집 �?HTML ?�성
Write-Log "Step 1: ?�스 ?�집 �?.."
try {
    # Python??UTF-8 모드�??�행
    $process = Start-Process -FilePath "python" -ArgumentList "generator2.py" -NoNewWindow -Wait -PassThru -RedirectStandardOutput "temp_output.txt" -RedirectStandardError "temp_error.txt"
    
    # 출력 ?�기 (UTF-8)
    if (Test-Path "temp_output.txt") {
        $output = Get-Content "temp_output.txt" -Encoding UTF8 -Raw
        if ($output) {
            $output -split "`n" | ForEach-Object { Write-Log $_ }
        }
        Remove-Item "temp_output.txt" -Force
    }
    
    if (Test-Path "temp_error.txt") {
        $errors = Get-Content "temp_error.txt" -Encoding UTF8 -Raw
        if ($errors) {
            $errors -split "`n" | ForEach-Object { Write-Log "ERROR: $_" }
        }
        Remove-Item "temp_error.txt" -Force
    }
    
    if ($process.ExitCode -eq 0) {
        Write-Log "SUCCESS: ?�스 ?�집 ?�공"
    }
    else {
        Write-Log "FAIL: ?�스 ?�집 ?�패 (Exit Code: $($process.ExitCode))"
        exit 1
    }
}
catch {
    Write-Log "ERROR: ?�류 발생: $_"
    exit 1
}

# 2. Git 변경사???�인
Write-Log "Step 2: Git 변경사???�인..."
$GitStatus = git status --porcelain
if ([string]::IsNullOrWhiteSpace($GitStatus)) {
    Write-Log "변경사???�음. ?�업 종료."
    Write-Log "=========================================="
    exit 0
}

Write-Log "변경된 ?�일:"
$GitStatus | ForEach-Object { Write-Log "  $_" }

# 3. Git Add
Write-Log "Step 3: Git add ?�행..."
git add . 2>&1 | Out-Null
if ($LASTEXITCODE -eq 0) {
    Write-Log "SUCCESS: Git add ?�공"
}
else {
    Write-Log "FAIL: Git add ?�패"
    exit 1
}

# 4. Git Commit
Write-Log "Step 4: Git commit ?�행..."
$CommitMessage = "Auto-update news - $(Get-Date -Format 'yyyy-MM-dd HH:mm')"
git commit -m $CommitMessage 2>&1 | Out-Null
if ($LASTEXITCODE -eq 0) {
    Write-Log "SUCCESS: Git commit ?�공: $CommitMessage"
}
else {
    Write-Log "FAIL: Git commit ?�패"
    exit 1
}

# 5. Git Push
Write-Log "Step 5: Git push ?�행..."
git push 2>&1 | Out-Null
if ($LASTEXITCODE -eq 0) {
    Write-Log "SUCCESS: Git push ?�공"
}
else {
    Write-Log "FAIL: Git push ?�패"
    exit 1
}

Write-Log "=========================================="
Write-Log "SUCCESS: 모든 ?�업 ?�료!"
Write-Log "=========================================="
exit 0
